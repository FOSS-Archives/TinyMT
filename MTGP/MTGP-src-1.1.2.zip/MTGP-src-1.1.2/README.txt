 =================================================================
 MTGP ver. 1.1.1
 2012.10.16

 Mersenne Twister for Graphic Processors(MTGP)
 based on IEEE 754 floating point format.

 Mutsuo Saito (Hiroshima University) and
 Makoto Matsumoto (The University of Tokyo)

 Copyright (c) 2009, 2010 Mutsuo Saito, Makoto Matsumoto and Hiroshima
 University.  All rights reserved.
 Copyright (c) 2011, 2012 Mutsuo Saito, Makoto Matsumoto, Hiroshima
 University and University of Tokyo.  All rights reserved.

 The (modified) BSD License is applied to this software, see
 LICENSE.txt
 =================================================================
 The documents written in English is the official one.

 To see documents, see html/index.html.

 This program only works on systems which have IEEE754 floating point
 format.

 This program can run on many systems, but designed for Graphic
 Processors. The program may very slow on normal CPUs.

 If you want to redistribute and/or change source files, see LICENSE.txt.

 When you change these files and redistribute them, PLEASE write your
 e-mail address in redistribution and write to contact YOU first if
 users of your changed source encounter troubles.
