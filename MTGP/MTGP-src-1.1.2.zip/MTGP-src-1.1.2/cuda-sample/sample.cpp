#include "sample-cuda.h"

int main(int argc, char * argv[])
{
    return sample_cuda(argc, argv);
}
