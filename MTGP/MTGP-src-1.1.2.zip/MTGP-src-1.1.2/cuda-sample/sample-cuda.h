#ifndef SAMPLE_CUDA_H
#define SAMPLE_CUDA_H
int sample_cuda(int argc, char * argv[]);
#endif
